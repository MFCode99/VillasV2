from __future__ import annotations

from dataclasses import dataclass
import json
from email.message import EmailMessage
import smtplib
from typing import Any, Callable

from jinja2 import Template
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import Settings, get_settings
from .models import EmailDeliveryLog, EmailTemplate, Order, User
from .pdf_service import build_order_pdf
from .security import utcnow


@dataclass(slots=True)
class EmailSendResult:
    status: str
    provider_message_id: str | None = None
    error_message: str | None = None




def _json_safe(value: Any) -> Any:
    return json.loads(json.dumps(value, default=str, ensure_ascii=False))

class EmailService:
    def __init__(
        self,
        settings: Settings | None = None,
        *,
        transport_factory: Callable[[Settings], smtplib.SMTP] | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.transport_factory = transport_factory or self._default_transport_factory

    def _default_transport_factory(self, settings: Settings) -> smtplib.SMTP:
        if settings.smtp_port == 465:
            client: smtplib.SMTP = smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=20)
        else:
            client = smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20)
            client.ehlo()
            if settings.smtp_port in {587, 25}:
                client.starttls()
                client.ehlo()
        if settings.smtp_user or settings.smtp_password:
            client.login(settings.smtp_user, settings.smtp_password)
        return client

    def _default_recipients(self, order: dict[str, Any]) -> list[str]:
        recipients: list[str] = []
        for value in [
            order.get('customerEmail') or order.get('customer_email'),
            self.settings.smtp_from,
            self.settings.smtp_user,
        ]:
            text = str(value or '').strip()
            if text and text not in recipients:
                recipients.append(text)
        return recipients

    def _render_template(self, db: Session, event: str, order: dict[str, Any]) -> tuple[str, str, str]:
        template = db.scalar(select(EmailTemplate).where(EmailTemplate.name == event, EmailTemplate.active.is_(True)))
        context = {
            'order': order,
            'public_number': order.get('publicNumber') or order.get('public_number'),
            'customer_name': order.get('customerName') or order.get('customer_name') or '',
            'total': order.get('total'),
            'status_label': order.get('orderStatusLabel') or order.get('order_status') or '',
        }
        if template is not None:
            subject = Template(template.subject).render(**context)
            body_html = Template(template.body_html).render(**context)
            body_text = Template(template.body_text or template.body_html).render(**context)
            return subject, body_html, body_text

        public_number = context['public_number']
        subject = f"Encomenda {public_number} - {context['status_label']}"
        body_text = (
            f"Encomenda {public_number}\n"
            f"Cliente: {context['customer_name']}\n"
            f"Estado: {context['status_label']}\n"
            f"Total: {context['total']}\n"
        )
        body_html = (
            f"<html><body><h1>Encomenda {public_number}</h1>"
            f"<p>Cliente: {context['customer_name']}</p>"
            f"<p>Estado: {context['status_label']}</p>"
            f"<p>Total: {context['total']}</p>"
            f"</body></html>"
        )
        return subject, body_html, body_text

    def _build_message(
        self,
        *,
        sender: str,
        recipients: list[str],
        subject: str,
        body_html: str,
        body_text: str,
        order: dict[str, Any],
        hide_prices: bool = False,
    ) -> EmailMessage:
        message = EmailMessage()
        message['From'] = sender
        message['To'] = ', '.join(recipients)
        message['Subject'] = subject
        message.set_content(body_text)
        message.add_alternative(body_html, subtype='html')
        attachments = [
            (f"{order.get('publicNumber') or order.get('public_number')}.pdf", build_order_pdf(order, hide_prices=hide_prices)),
            (f"{order.get('publicNumber') or order.get('public_number')}_sem_precos.pdf", build_order_pdf(order, hide_prices=True)),
        ]
        for filename, pdf_bytes in attachments:
            message.add_attachment(pdf_bytes, maintype='application', subtype='pdf', filename=filename)
        return message

    def send_order_event(
        self,
        db: Session,
        *,
        order: dict[str, Any],
        event: str,
        request_id: str | None,
        related_user_id: int | None = None,
        attempt: int = 1,
    ) -> EmailSendResult:
        recipients = self._default_recipients(order)
        sender = self.settings.smtp_from or self.settings.smtp_user or 'noreply@example.test'
        subject, body_html, body_text = self._render_template(db, event, order)
        log = EmailDeliveryLog(
            related_order_id=order.get('id'),
            related_user_id=related_user_id or order.get('userId'),
            template_name=event,
            request_id=request_id,
            attempt=attempt,
            recipient=', '.join(recipients) if recipients else '',
            subject=subject,
            status='pending',
            payload_json=_json_safe({'event': event, 'order': order, 'request_id': request_id}),
        )
        db.add(log)
        db.commit()
        db.refresh(log)

        if not recipients or not self.settings.smtp_host:
            log.status = 'failed'
            log.error_message = 'smtp_not_configured'
            order_row = db.get(Order, order.get('id'))
            if order_row is not None:
                order_row.email_status = 'failed'
                order_row.email_error = 'smtp_not_configured'
                order_row.email_sent_at = None
            db.commit()
            return EmailSendResult(status='failed', error_message='smtp_not_configured')

        message = self._build_message(
            sender=sender,
            recipients=recipients,
            subject=subject,
            body_html=body_html,
            body_text=body_text,
            order=order,
        )

        client = None
        try:
            client = self.transport_factory(self.settings)
            result = client.send_message(message)
            provider_message_id = None
            if hasattr(client, 'sock') and getattr(client, 'sock', None) is not None:
                provider_message_id = getattr(client.sock, 'getsockname', lambda: None)() or None
            log.status = 'sent'
            log.provider_message_id = str(provider_message_id or result or '')
            log.error_message = None
            order_row = db.get(Order, order.get('id'))
            if order_row is not None:
                order_row.email_status = 'sent'
                order_row.email_error = None
                order_row.email_sent_at = utcnow()
            db.commit()
            return EmailSendResult(status='sent', provider_message_id=log.provider_message_id)
        except Exception as exc:
            log.status = 'failed'
            log.error_message = str(exc)
            order_row = db.get(Order, order.get('id'))
            if order_row is not None:
                order_row.email_status = 'failed'
                order_row.email_error = str(exc)
                order_row.email_sent_at = None
            db.commit()
            return EmailSendResult(status='failed', error_message=str(exc))
        finally:
            try:
                if client is not None:
                    client.quit()
            except Exception:
                pass

    def send_user_created(self, db: Session, *, user: User, password: str, request_id: str | None) -> EmailSendResult:
        recipient = str(user.email or '').strip()
        sender = self.settings.smtp_from or self.settings.smtp_user or 'noreply@example.test'
        subject = 'Bem-vindo ao Portal Comercial Villas'
        body_text = (
            f'Olá {user.full_name},\n\nA sua conta no Portal Comercial Villas foi criada.\n\n'
            f'Utilizador: {user.username}\nPassword: {password}\n\n'
            f'Aceda ao portal em: {self.settings.public_url}\n'
        )
        body_html = (
            f'<html><body><h1>Bem-vindo ao Portal Comercial Villas</h1><p>Olá {user.full_name},</p>'
            f'<p>A sua conta foi criada.</p><p><b>Utilizador:</b> {user.username}<br/>'
            f'<b>Password:</b> {password}</p><p><a href="{self.settings.public_url}">Abrir o portal</a></p></body></html>'
        )
        log = EmailDeliveryLog(
            related_user_id=user.id,
            template_name='user_created',
            request_id=request_id,
            attempt=1,
            recipient=recipient,
            subject=subject,
            status='pending',
            payload_json=_json_safe({'event': 'user_created', 'user_id': user.id, 'request_id': request_id}),
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        if not recipient or not self.settings.smtp_host:
            log.status = 'failed'
            log.error_message = 'smtp_not_configured' if not self.settings.smtp_host else 'user_email_missing'
            db.commit()
            return EmailSendResult(status='failed', error_message=log.error_message)
        message = EmailMessage()
        message['From'] = sender
        message['To'] = recipient
        message['Subject'] = subject
        message.set_content(body_text)
        message.add_alternative(body_html, subtype='html')
        client = None
        try:
            client = self.transport_factory(self.settings)
            result = client.send_message(message)
            log.status = 'sent'
            log.provider_message_id = str(result or '')
            log.error_message = None
            db.commit()
            return EmailSendResult(status='sent', provider_message_id=log.provider_message_id)
        except Exception as exc:
            log.status = 'failed'
            log.error_message = str(exc)
            db.commit()
            return EmailSendResult(status='failed', error_message=str(exc))
        finally:
            try:
                if client is not None:
                    client.quit()
            except Exception:
                pass
