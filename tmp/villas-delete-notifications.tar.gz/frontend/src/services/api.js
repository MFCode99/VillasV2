import axios from 'axios'

export function cookie(name) {
  return document.cookie.split('; ').find(row => row.startsWith(`${name}=`))?.split('=').slice(1).join('=') || ''
}

export const api = axios.create({
  baseURL: '/api/v1',
  withCredentials: true,
  headers: { Accept: 'application/json' }
})

export const rootApi = axios.create({ withCredentials: true, headers: { Accept: 'application/json' } })

api.interceptors.request.use(config => {
  const method = (config.method || 'get').toLowerCase()
  if (!['get', 'head', 'options'].includes(method)) config.headers['X-CSRF-Token'] = decodeURIComponent(cookie('villas_v2_csrf'))
  return config
})
rootApi.interceptors.request.use(config => {
  const method = (config.method || 'get').toLowerCase()
  if (!['get', 'head', 'options'].includes(method)) config.headers['X-CSRF-Token'] = decodeURIComponent(cookie('villas_v2_csrf'))
  return config
})

export function errorMessage(error) {
  const detail = error?.response?.data?.detail
  const labels = {
    invalid_credentials: 'Utilizador ou password incorretos.', login_required: 'A sessão terminou. Volte a entrar.',
    forbidden: 'Não tem permissão para esta operação.', username_exists: 'Esse utilizador já existe.',
    user_has_history: 'Este utilizador tem histórico e não pode ser eliminado.', cannot_delete_self: 'Não pode eliminar a sua própria conta.',
    password_too_short: 'A password deve ter pelo menos 8 caracteres.', product_not_available: 'Este produto já não está disponível.',
    product_in_use: 'Este produto não pode ser eliminado porque já existe em carrinhos ou encomendas.',
    cart_empty: 'O carrinho está vazio.', invalid_quantity_step: 'A quantidade não respeita o múltiplo definido.',
    invalid_image_format: 'O ficheiro escolhido não é uma imagem válida ou não pode ser convertido.',
    image_too_large: 'A imagem é demasiado grande. O limite é 8 MB.',
    image_dimensions_too_large: 'A imagem tem dimensões demasiado grandes.'
  }
  if (typeof detail === 'string') return labels[detail] || detail.replaceAll('_', ' ')
  return error?.message || 'Ocorreu um erro inesperado.'
}

export function idempotencyKey(prefix = 'web') {
  return `${prefix}-${crypto.randomUUID()}`
}
