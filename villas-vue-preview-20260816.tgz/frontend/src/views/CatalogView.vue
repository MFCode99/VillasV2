<script setup>
import { onMounted, reactive, ref, watch } from 'vue'
import { api, errorMessage } from '../services/api'
import { useFeedbackStore } from '../stores/feedback'
const feedback = useFeedbackStore(); const result = ref({ items: [], categories: [], total: 0, pages: 1, page: 1 }); const loading = ref(false)
const filters = reactive({ q: '', category: null, season: null, sort: 'ref_asc', page: 1 }); let timer
const seasons = [{ title: 'Todas as estações', value: null }, { title: 'Todo o ano', value: 'ambos' }, { title: 'Inverno', value: 'inverno' }, { title: 'Verão', value: 'verao' }]
const sorts = [{ title: 'Referência', value: 'ref_asc' }, { title: 'Nome A–Z', value: 'name_asc' }, { title: 'Preço crescente', value: 'price_asc' }, { title: 'Preço decrescente', value: 'price_desc' }]
async function load() { loading.value = true; try { result.value = (await api.get('/catalog', { params: { ...filters, per_page: 24 } })).data } catch (e) { feedback.show(errorMessage(e), 'error') } finally { loading.value = false } }
watch(filters, () => { clearTimeout(timer); timer = setTimeout(load, 250) }, { deep: true }); onMounted(load)
</script>
<template><div class="page"><div class="page-head"><div><h1>Catálogo</h1><p>{{ result.total }} produtos disponíveis.</p></div><v-btn to="/carrinho" color="primary" prepend-icon="mdi-cart-outline">Ver carrinho</v-btn></div>
  <v-card class="soft-card pa-4 mb-6"><v-row dense><v-col cols="12" md="5"><v-text-field v-model="filters.q" hide-details clearable label="Pesquisar nome ou referência" prepend-inner-icon="mdi-magnify" /></v-col><v-col cols="12" sm="4" md="3"><v-select v-model="filters.category" hide-details clearable label="Categoria" :items="result.categories" item-title="label" item-value="slug" /></v-col><v-col cols="6" sm="4" md="2"><v-select v-model="filters.season" hide-details label="Estação" :items="seasons" /></v-col><v-col cols="6" sm="4" md="2"><v-select v-model="filters.sort" hide-details label="Ordenar" :items="sorts" /></v-col></v-row></v-card>
  <v-row v-if="loading"><v-col v-for="i in 8" :key="i" cols="12" sm="6" md="4" lg="3"><v-skeleton-loader type="image, article" /></v-col></v-row>
  <v-row v-else><v-col v-for="product in result.items" :key="product.ref" cols="12" sm="6" md="4" lg="3"><v-card class="soft-card clickable h-100" :to="`/catalogo/${product.ref}`"><v-img :src="product.imageUrl" height="220" class="product-image"><template #error><div class="d-flex fill-height align-center justify-center"><v-icon size="54" color="grey-lighten-1">mdi-image-outline</v-icon></div></template></v-img><v-card-text><div class="text-caption text-medium-emphasis">{{ product.ref }} · {{ product.categoryLabel }}</div><div class="text-subtitle-1 font-weight-bold mt-1 text-truncate">{{ product.name }}</div><div class="d-flex justify-space-between align-end mt-4"><v-chip size="small" variant="tonal">{{ product.season }}</v-chip><span class="text-h6 font-weight-black">{{ Number(product.price).toFixed(2) }} €</span></div></v-card-text></v-card></v-col></v-row>
  <div v-if="!loading && !result.items.length" class="empty-state"><v-icon size="52">mdi-package-variant-remove</v-icon><div class="text-h6 mt-3">Nenhum produto encontrado</div><div>Experimente alterar a pesquisa ou os filtros.</div></div>
  <v-pagination v-if="result.pages > 1" v-model="filters.page" :length="result.pages" class="mt-8" />
</div></template>
