from uuid import uuid4

from app.db import SessionLocal
from app.services import UserAdminService


def _user(role='client'):
    username = f'{role}_{uuid4().hex}'
    with SessionLocal() as db:
        user = UserAdminService().create_user(
            db,
            username=username,
            password='secret123',
            full_name='API Test',
            role=role,
            active=True,
        )
        return username, user.id


def _api_login(client, role='client'):
    username, user_id = _user(role)
    response = client.post('/api/v1/auth/login', json={'username': username, 'password': 'secret123'})
    assert response.status_code == 200
    return response.json(), user_id


def test_api_session_and_login(client):
    assert client.get('/api/v1/session').json()['authenticated'] is False
    payload, _ = _api_login(client)
    assert payload['user']['role'] == 'client'
    assert client.get('/api/v1/session').json()['authenticated'] is True


def test_api_rejects_private_data_without_session(client):
    assert client.get('/api/v1/catalog').status_code == 401
    assert client.get('/api/v1/admin/users').status_code == 401


def test_api_admin_can_create_and_toggle_user(client):
    login, _ = _api_login(client, 'admin')
    headers = {'X-CSRF-Token': login['csrfToken']}
    username = f'new_{uuid4().hex}'
    response = client.post('/api/v1/admin/users', headers=headers, json={
        'username': username,
        'password': 'secret123',
        'full_name': 'Novo Cliente',
        'role': 'client',
        'active': True,
    })
    assert response.status_code == 201
    user = response.json()['user']
    toggle = client.patch(f"/api/v1/admin/users/{user['id']}/active", headers=headers, json={'active': False})
    assert toggle.status_code == 200
    assert toggle.json()['user']['active'] is False


def test_vue_history_routes_serve_built_app(client):
    response = client.get('/nova/admin/utilizadores')
    assert response.status_code == 200
    assert '<div id="app"></div>' in response.text
